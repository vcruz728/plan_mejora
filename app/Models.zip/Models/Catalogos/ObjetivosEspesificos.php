<?php

namespace App\Models\Catalogos;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ObjetivosEspesificos extends Model
{
    use HasFactory;

    protected $table = 'cat_objetivos_espesifico';
}
