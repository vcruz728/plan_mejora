<?php

namespace App\Models\Catalogos;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UnidadesAcademicas extends Model
{
    use HasFactory;

    protected $table = 'cat_unidades_academicas';
}
