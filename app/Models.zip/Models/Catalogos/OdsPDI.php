<?php

namespace App\Models\Catalogos;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class OdsPDI extends Model
{
    use HasFactory;

    protected $table = 'cat_ods_pdi';
}
