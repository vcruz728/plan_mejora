<?php

namespace App\Models\Catalogos;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ProgramasEducativos extends Model
{
    use HasFactory;

    protected $table = 'cat_programas_educativos_dos';
}
