<?php

namespace App\Models\Mejoras;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ComplementosPlan extends Model
{
    use HasFactory;

    protected $table = 'complemento_plan';
}
