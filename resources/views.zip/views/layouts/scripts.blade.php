<script src="{{ asset('js/jquery-ui.js') }}"></script>
<script src="{{ asset('bower_components/bootstrap/dist/js/bootstrap.min.js') }}"></script>

<script src="{{ asset('dist/js/adminlte.min.js') }}"></script>
<script src="{{ asset('dist/js/demo.js') }}"></script>
<script src="{{ asset('js/moment.min.js') }}"></script>
<script src="{{ asset('js/moment-locale-es.js') }}"></script>
<script src="{{ asset('js/xlsx.full.min.js') }}"></script>
<script src="{{ asset('js/numeral.min.js') }}"></script>

<script src="{{ asset('highcharts/highcharts.js') }}"></script>
<script src="{{ asset('highcharts/highcharts-more.js') }}"></script>
<script src="{{ asset('highcharts/modules/exporting.js') }}"></script>
<script src="{{ asset('highcharts/modules/export-data.js') }}"></script>
<script src="{{ asset('highcharts/modules/accessibility.js') }}"></script>
<script src="{{ asset('bower_components/sweetalert/sweetalert.min.js') }}"></script>
<script src="{{ asset('js/toastr/toastr.min.js') }}"></script>
